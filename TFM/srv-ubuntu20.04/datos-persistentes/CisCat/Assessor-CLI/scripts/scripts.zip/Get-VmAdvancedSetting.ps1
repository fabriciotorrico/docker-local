$advancedSetting=$args[0]
$Output =
    Get-VM | Get-AdvancedSetting -Name ${advancedSetting} | Select Entity, Name, Value
$Output | ConvertTo-Csv -NoTypeInformation