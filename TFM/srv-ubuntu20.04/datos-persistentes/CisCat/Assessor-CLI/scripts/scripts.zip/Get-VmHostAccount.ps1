$Output =
    Get-VMHostAccount | % {$f = $_; Get-VIPermission | ? {$f.Name -eq $_.Principal} | Select @{n='Server';e={$f.Server}}, @{n='Name';e={$f.Name}}, @{n='Domain';e={$f.Domain}}, @{n='Description';e={$f.Description}}, @{n='ShellAccessEnabled';e={$f.ShellAccessEnabled}}, @{n='Role';e={$_.Role}}}
$Output | ConvertTo-Csv -NoTypeInformation